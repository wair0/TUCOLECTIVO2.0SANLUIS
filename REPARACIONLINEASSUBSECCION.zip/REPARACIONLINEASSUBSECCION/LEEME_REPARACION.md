# Reparación de LÍNEAS y subsecciones (TU COLECTIVO 2.0)

## Qué estaba mal (causas reales, encontradas en el repositorio)
1. `style.css` tiene `.screen-head{display:none!important}`: ocultaba la cabecera de las subsecciones (botón atrás, título CALLES / INTERSECCIONES / PARADAS / ARRIBOS y contexto).
2. `style-ht.css` tiene `html[data-theme=dark] .line-card / .data-card / .arrival-card{background:…}` (más específico que `lineas.css`): por eso las tarjetas salían grises y azuladas, y su `::after` con `border-radius:inherit` las redondeaba.
3. `style.css` tiene `.line-card::before{width:4px;…}`: el relleno interno de la tarjeta quedaba reducido a una barrita de 4 px (la franja oscura de la izquierda).
4. `style.css` tiene `.data-card{flex-direction:column}`, `.data-card span{font-size:10px;color:var(--mut)}` y `.line-card b{font-size:22px!important}`: desarmaban la fila de las tarjetas de calles/intersecciones/paradas y agrandaban el número.
5. `style.css` tiene `.arrival-card .arrival-copy span{color:cyan!important}` y `.arrival-arriving{background:…}`: teñían de cian los textos de los arribos y metían un recuadro detrás de ARRIBANDO.
6. Error mío en `lineas.js`: la tarjeta de línea mostraba el código interno de SmartMove (293, 326…) como texto grande. Incumplía la regla "no mostrar códigos internos como identificación pública". Ahora el hexágono lleva el icono de ruta y se muestra LÍNEA + nombre público (A, BCG, 110…). El código interno solo viaja en `data-line`.
7. El fondo de la app seguía azul en modo oscuro porque `style.css` define sus propias variables (`--bg`, `--sf`…).

## Archivos (rutas del repositorio; reemplazar tal cual)
- `app/src/main/assets/lineas.css`   el de ahora + un bloque final "REPARACIÓN DE LÍNEAS Y SUBSECCIONES", todo acotado a `[data-screen="lineas"]` (no toca MAPA, PARADAS CERCANAS ni FAVORITOS).
- `app/src/main/assets/lineas.js`    el de ahora (con su `bindPress`) + `lineCardHtml` corregida.
- `app/src/main/assets/theme-dark.css`   OPCIONAL: agrega variables heredadas en negro (fondo #000, superficies casi negras, texto principal oro neón) para que el modo oscuro deje de verse azul en todas las secciones. Si prefieres arreglar solo LÍNEAS, no lo reemplaces.
No hay que tocar `index.html`, `script.js`, `style.css`, `style-ht.css` ni `circuits.css` (el workflow `generar-circuits.yml` sigue funcionando igual).

## Cómo se verificó
Se cargó el `index.html` real del repositorio con un puente `TuColectivoNative` simulado (líneas, calles, intersecciones, paradas y arribos de ejemplo) y se recorrió LÍNEAS → CALLES → INTERSECCIONES → PARADAS → ARRIBOS en modo claro y oscuro, sin errores de JavaScript. `docs/preview_reparacion_lineas.html` es esa misma app (con los archivos reparados) en un solo HTML: ábrelo en el navegador del teléfono.
