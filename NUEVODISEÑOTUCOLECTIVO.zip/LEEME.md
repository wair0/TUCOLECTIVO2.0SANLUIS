# TU COLECTIVO 2.0 - Título animado, SINCRONIZAR LÍNEAS y sección LÍNEAS (High-Tech Corporativo)

Todo en HTML5/CSS3/JS vanilla, offline, sin CDN ni fuentes externas, claro/oscuro automático (tokens `--tcn-*` del header).

## Archivos (carpeta webview/)
- circuits.css                           CIRCUITOS ELECTRÓNICOS en lugar de la retícula de puntos (header, paneles, barra inferior, tarjetas, líneas, arribos). Se carga AL FINAL, después de theme-dark.css
- theme-dark.css                         MODO OSCURO NEGRO con textos oro neón (se carga AL FINAL, después de todos los demás CSS; no hace falta editar header.css ni bottom-nav.css)
- header-title.css + header-title.html   título "TU COLECTIVO 2.0" nuevo (se carga DESPUÉS de header.css; el .html reemplaza el <h1> del header)
- home-cards.css / .html / .js           las 4 tarjetas de inicio (sin cambios) + tarjeta SINCRONIZAR LÍNEAS con barra de progreso (reemplaza los 3 archivos anteriores)
- lineas.css + lineas.js                 estilo de toda la sección LÍNEAS: líneas, calles, intersecciones, paradas y arribos (se carga DESPUÉS de style.css y style-ht.css)
- docs/preview_titulo_sync_lineas.html   vista previa interactiva (header, inicio, sincronizar, líneas completas, barra inferior; AUTO/CLARO/OSCURO)
- docs/PROMPT_CHATGPT_GITHUB.md          texto listo para pegar en ChatGPT con el conector de GitHub

## Título del header
Fuente propia de trazo geométrico dibujada en SVG y aplicada como máscara CSS (no depende de ninguna fuente del teléfono), más una etiqueta "2.0".
Animación: barrido de revelado con cursor de escaneo, destello que recorre las letras y pulso suave de la etiqueta. El texto real queda en aria-label. Tamaño compacto (~150 px de ancho): variable `--wm` (.82 por defecto; .9 para un poco más grande).

## Circuitos
`circuits.css` quita los puntos y dibuja pistas de circuito impreso con giros de 45°, pads y vías (SVG inline, sin imágenes externas). Las pistas salen de los hexágonos de icono y terminan pegadas a cada texto (en el header y la barra inferior el texto queda enmarcado con corchetes de circuito): título y chip del header, etiquetas de la barra inferior (una por etiqueta), nombre de cada tarjeta de inicio, nombre y barra de SINCRONIZAR LÍNEAS, líneas y detalle de LÍNEAS, y cada fila de los arribos y de la parada. Color según el tema (azul en claro, cian en oscuro, rojo en ARRIBANDO). Los fondos siguen 100% opacos.
**Header:** del vértice de cada botón hexagonal salen dos pistas a 45°, una al título (que queda entre corchetes) y otra al chip de sección, donde terminan en su borde. **Barra inferior:** una pista continua une todas las etiquetas, cada una entre corchetes, y un tallo baja desde cada icono hasta su etiqueta.
**Animación (header, barra inferior y tarjetas de arribos):** pulsos de luz recorren las pistas hacia cada texto (título y chip en el header, una pista por etiqueta en la barra inferior) y los pads destellan cuando llega el pulso. En cada tarjeta de arribos un pulso baja por la barra izquierda y destella en el pad de cada fila (LINEA / HACIA), y una pista que cruza toda la tarjeta (entre las dos filas de texto) lleva un pulso hasta el círculo del contador, donde termina en un pad pegado al borde del círculo; en ARRIBANDO la pista termina junto al texto, que queda enmarcado con corchetes de circuito, y todo es rojo. Las tarjetas pares van desfasadas de las impares; los tiempos están desfasados para que no parpadeen todos a la vez. La animación va dentro de cada SVG (CSS embebido), sin JavaScript; con `prefers-reduced-motion` se desactiva sola. El archivo se genera con colores fijos por tema porque un SVG embebido no puede leer variables CSS.

## Modo oscuro
`theme-dark.css` cambia solo los tokens del modo oscuro: fondos negros (#000), bordes grafito, texto principal oro neón #FFD60A (con un resplandor suave en títulos y etiquetas), acento cian y contador de minutos verde neón. El modo claro no cambia.

## SINCRONIZAR LÍNEAS
Tarjeta ancha bajo las 4 tarjetas. Cada pulsación lleva la barra de 0 a 100 %: el icono gira, aparece el porcentaje, al llegar a 100 % cambia a un check y la barra vuelve a 0 para la siguiente pulsación. Mientras corre, nuevas pulsaciones se ignoran.
- Modo automático (por defecto): la barra corre sola en ~3,2 s.
- Modo real: `TcHomeCards.syncManual = true` y reportar desde nativo `TcHomeCards.sync.progress(0..100)`, `.done()` o `.fail()`.
- `TcHomeCards.onSync = function(){ /* aquí va la sincronización real, p. ej. loadLines() */ }`. Evento `tc:sync` (detail.action = start | done | fail).

## Sección LÍNEAS
Estilos para las clases que ya usa la app (`screen-head`, `lineas-grid`, `data-card line-detail-card`, `arrival-list`, `arrival-card`, `arrival-copy`, `arrival-time`, `arrival-ring-orbit`, animaciones `arrivalNativeOrbit` y `arrivalArrivingPulse`) y clases nuevas (`line-card`, `line-list`, `tc-btn`, `tc-stop`, `tc-state`, `tc-crumbs`, `tc-back`).
`lineas.js` solo trae ayudas visuales y el marcado de referencia (`TcLineas.lineCardHtml`, `detailCardHtml`, `arrivalCardHtml`, `stateHtml`) + `TcLineas.bindPress(raiz)` para el efecto al tocar. No contiene lógica de negocio ni llamadas a SmartMove.
El número del centro del círculo es verde neón (verde más oscuro en modo claro para que se lea) y está animado: pulso con resplandor continuo y cuenta visual de 0 al valor al dibujarse (`TcLineas.animateNumbers(contenedor)`; solo animación, no es un cronómetro).
Respeta las reglas del documento de estructura: el círculo del contador usa viewBox 0 0 80 80, r=35 y `--arrival-duration` = max(1,2, min(18, m·0,35)) s (8 s si no hay minutos); es solo una representación visual, no resta minutos. ARRIBANDO / LLEGANDO / EN PARADA / PRÓXIMO o m ≤ 1 muestran la etiqueta ARRIBANDO en rojo con pulso de 1,05 s; también están SIN ARRIBOS, ERROR DE ARRIBOS y ACTUALIZANDO MINUTOS.
Todos los nombres, rutas y minutos de la vista previa son DATOS DE EJEMPLO; los reales los entrega SmartMove.
