Pega esto en ChatGPT con el conector de GitHub activado (repo wair0/TUCOLECTIVO2.0SANLUIS):

---
Trabaja DIRECTAMENTE sobre la rama existente `native/cyberpunkwebview-ui`. NO crees ramas nuevas ni Pull Requests: haz commits y push en esa misma rama. La app es nativa (Kotlin + Python) con interfaz en WebView (HTML5/CSS3/JS vanilla, offline, sin frameworks ni CDN). No modifiques Kotlin, Python, SmartMove/SOAP, GPS, mapa, favoritos ni la lógica de `script.js` salvo lo indicado.

ARCHIVOS del zip (carpeta `webview/`, cópialos a `app/src/main/assets/` junto a `header.*` y `bottom-nav.*`):
circuits.css, theme-dark.css, header-title.css, header-title.html, home-cards.css, home-cards.html, home-cards.js, lineas.css, lineas.js.
`docs/preview_titulo_sync_lineas.html` es la referencia visual exacta: si algo no coincide, el resultado debe verse igual a esa vista previa.

0) MODO OSCURO NEGRO
- Enlaza `theme-dark.css` AL FINAL, después de header.css, header-title.css, bottom-nav.css, home-cards.css, lineas.css y los CSS existentes. El modo oscuro debe ser NEGRO (#000, no azul) con texto principal oro neón (#FFD60A) y el número del contador de arribos en verde neón. Si el `<meta name="theme-color">` o el fondo del body/WebView en Kotlin es azul oscuro, cámbialo a #000000 (avísame si está en código nativo). No dejes colores azules fijos de fondo en style.css / style-ht.css para el modo oscuro.

0b) CIRCUITOS EN LOS FONDOS
- Enlaza `circuits.css` AL FINAL de todo (después de `theme-dark.css`). Reemplaza la retícula de puntos de fondo de header, paneles del header, barra inferior, tarjetas de inicio, SINCRONIZAR LÍNEAS y la sección LÍNEAS por pistas de circuito electrónico conectadas a los textos. No agregues otra vez `radial-gradient` de puntos en esos fondos ni cambies `background-image`/`background-size`/`background-position` de los `::before` de `.tc-hd`, `.tc-hd-panel`, `.tc-nav`, `.tc-card`, `.line-card`, `.line-detail-card`, `.arrival-card` y `.tc-stop`. Las pistas del header, de la barra inferior y de las tarjetas de arribos (`.arrival-card`, incluidas las variantes `.arriving`, `.selected` y `.hot`) están ANIMADAS (pulsos de luz que viajan hacia cada texto, animación CSS dentro del propio SVG): no las reemplaces por imágenes estáticas ni agregues JavaScript para animarlas. En el header las pistas nacen en los vértices de los botones (menú a la izquierda, búsqueda a la derecha) y se calculan con el ancho de los botones y del título; en la barra inferior dependen del ancho de cada etiqueta. Las posiciones de las pistas dependen del tamaño real del título, las etiquetas y las tarjetas de la vista previa; si cambias esos tamaños o textos, avísame para regenerar el archivo.

1) TÍTULO DEL HEADER
- Enlaza `header-title.css` DESPUÉS de `header.css`. El título es compacto (`--wm:.82`); no lo agrandes.
- En el header reemplaza `<h1 class="tc-hd-title">TU COLECTIVO 2.0</h1>` por el `<h1 class="tc-hd-title tc-wm" ...>` de `header-title.html` (sin el comentario). Si `header.js` o `script.js` leen o escriben el texto de ese <h1>, avísame antes de tocarlo.

2) INICIO: tarjetas + SINCRONIZAR LÍNEAS
- Reemplaza `home-cards.css`, `home-cards.html` y `home-cards.js` por los nuevos (ya incluyen las 4 tarjetas MAPA, LÍNEAS, PARADAS CERCANAS, FAVORITOS y la tarjeta ancha SINCRONIZAR LÍNEAS, id `tc-sync`). Elimina la tarjeta SINCRONIZAR LÍNEAS anterior para que no quede duplicada, pero conserva su lógica.
- Las tarjetas deben ser 100% opacas: no agregues `opacity`, `backdrop-filter` ni `rgba()` al fondo de `.tc-card`. `--tcn-page` debe coincidir con el fondo real de la app (claro #EEF3FC, oscuro #060D1C).
- Conecta: `TcHomeCards.onSelect = function(seccion){ ...navegación existente...; TcBottomNav.setActive(seccion); TcHeader.setSection(seccion); }` y `TcHomeCards.replay()` al volver a INICIO.
- Conecta la sincronización existente en `TcHomeCards.onSync = function(){ ...lo que hoy hace el botón (p. ej. loadLines())... }`. La barra debe ir de 0 a 100 % en cada pulsación. Si la app puede reportar el avance real, pon `TcHomeCards.syncManual = true` y llama a `TcHomeCards.sync.progress(n)` (0-100), `TcHomeCards.sync.done()` al terminar o `TcHomeCards.sync.fail()` si falla; si no, déjalo en modo automático. No inventes porcentajes.

3) SECCIÓN LÍNEAS (líneas, calles, intersecciones, paradas y arribos)
- Enlaza `lineas.css` DESPUÉS de `style.css` y `style-ht.css`, y `lineas.js` al final del body (después de header.js, bottom-nav.js y home-cards.js). Llama una vez a `TcLineas.bindPress(document.body)`.
- NO cambies el flujo ni los datos: LÍNEAS → CALLES → INTERSECCIONES → PARADAS → ARRIBOS con las funciones nativas actuales (loadLines, loadStreets, loadIntersections, loadStops, loadArrivals y sus callbacks onNative*), la normalización de nombres (quitar sufijo SAN LUIS), el botón Atrás, ACTUALIZAR MINUTOS (temporizador visual de 1200 ms), AGREGAR ARRIBO A FAVORITOS y VER RECORRIDO EN EL MAPA.
- Solo adapta el marcado que generan `renderLines`, `showList` y `showArrivals` en `script.js` para que use las clases de `lineas.css`. Las funciones `TcLineas.lineCardHtml`, `detailCardHtml`, `arrivalCardHtml` y `stateHtml` de `lineas.js` muestran el marcado de referencia: úsalas o replica su estructura conservando los atributos `data-*` y los ids/clases que usa la lógica actual. Resumen:
  · Cabecera: `.screen-head` con botón `.tc-back` (hexágono + flecha), `h2.screen-title` y `p.screen-sub`; migas opcionales `.tc-crumbs > .tc-crumb`.
  · Líneas: `.lineas-grid` con `button.line-card[data-line]` (número en hexágono, nombre público, cantidad de rutas, flecha).
  · Calles / intersecciones / paradas: contenedor `.line-list` con `button.data-card.line-detail-card` (rombo, nombre, etiqueta `.ld-tag` "ARRIBOS" solo en paradas, flecha).
  · Arribos: `.tc-stop` (descripción de la parada y "calle · intersección"), `.tc-actions` con los botones `.tc-btn` (AGREGAR ARRIBO A FAVORITOS normal, ACTUALIZAR MINUTOS con `.tc-btn-primary`), `.arrival-list` con `.arrival-card` (`.arrival-copy` LINEA/HACIA y `.arrival-time` con el círculo SVG viewBox 0 0 80 80 y `.arrival-num > b.arrival-n[data-m] + small` en el centro), y el botón VER RECORRIDO EN EL MAPA como `.tc-btn` (deshabilitado hasta elegir destino).
  · Estados: `.tc-state.is-loading` (ACTUALIZANDO MINUTOS), `.is-empty` (SIN ARRIBOS), `.is-error` (ERROR DE ARRIBOS). Añade la clase `tc-enter` y `style="--n:índice"` a las tarjetas para la animación de entrada.
- Después de dibujar los arribos llama a `TcLineas.animateNumbers(contenedor)` (cuenta visual 0 → minutos; el número del círculo es verde neón con pulso). Conserva la regla actual del círculo: `--arrival-duration` = max(1.2, min(18, m*0.35)) s (8 s si no hay minutos), el giro es solo visual y no resta minutos; ARRIBANDO / LLEGANDO / EN PARADA / PROXIMO(A) o m ≤ 1 reemplazan el círculo por la etiqueta ARRIBANDO (clase `.arriving` en la tarjeta). No inventes ni hardcodees calles, paradas ni minutos: los datos siguen viniendo de SmartMove.
- Elimina de `style.css` / `style-ht.css` las reglas antiguas que ya no se usen solo si estás seguro; si no, deja que `lineas.css` las sobrescriba.

4) Verifica que compile (GitHub Actions) y que ambos temas (claro/oscuro) funcionen. Si alguna parte actual está hecha con otra tecnología (XML nativo o Compose) o el marcado real difiere mucho del descrito, avísame antes de cambiar nada. Resume los archivos modificados en el mensaje del commit.
---
